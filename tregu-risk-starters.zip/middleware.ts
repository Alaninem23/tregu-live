import { NextRequest, NextResponse } from 'next/server';

// Simple dev-safe rate limiter. Replace with Redis in production.
const BUCKETS: Record<string, { count: number; reset: number }> = {};
const WINDOW_MS = 60_000; // 1 minute
const LIMIT_PER_IP = 60;

function key(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'local';
  const path = new URL(req.url).pathname;
  // group by path classes
  const group = path.startsWith('/api/auth') ? 'auth' :
                path.startsWith('/api/upload') ? 'upload' :
                path.startsWith('/api/checkout') ? 'checkout' : 'other';
  return `${ip}:${group}`;
}

export function middleware(req: NextRequest) {
  const k = key(req);
  const now = Date.now();
  const bucket = BUCKETS[k] || { count: 0, reset: now + WINDOW_MS };
  if (now > bucket.reset) {
    bucket.count = 0;
    bucket.reset = now + WINDOW_MS;
  }
  bucket.count += 1;
  BUCKETS[k] = bucket;
  const remaining = Math.max(0, LIMIT_PER_IP - bucket.count);
  const resHeaders = new Headers({
    'X-RateLimit-Limit': String(LIMIT_PER_IP),
    'X-RateLimit-Remaining': String(remaining),
    'X-RateLimit-Reset': String(Math.ceil(bucket.reset / 1000)),
  });
  if (bucket.count > LIMIT_PER_IP) {
    return new NextResponse('Too Many Requests', { status: 429, headers: resHeaders });
  }
  return NextResponse.next({ headers: resHeaders });
}

export const config = {
  matcher: ['/api/:path*'],
};
