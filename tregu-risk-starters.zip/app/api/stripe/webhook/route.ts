import { NextRequest, NextResponse } from 'next/server';
// import Stripe from 'stripe'; // install when enabling
// const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2024-06-20' });

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature') || '';
  const rawBody = await req.text();

  // TODO: Verify signature with STRIPE_WEBHOOK_SECRET and construct the event.
  // const event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET!);

  // Switch on event.type and call your handlers in lib/payments/events.ts
  return NextResponse.json({ ok: true });
}

export const config = {
  api: { bodyParser: false },
};
