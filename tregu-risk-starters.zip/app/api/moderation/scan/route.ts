import { NextRequest, NextResponse } from 'next/server';
import { scanText } from '@/lib/moderation/rules';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const text = String(body.text || '');
  const result = scanText(text);
  return NextResponse.json(result);
}
