import { NextRequest, NextResponse } from 'next/server';
import { isAllowedMime } from '@/lib/uploads/validation';

export async function POST(req: NextRequest) {
  const { filename, contentType, size } = await req.json();
  if (!filename || !contentType || typeof size !== 'number') {
    return NextResponse.json({ error: 'Invalid payload' }, { status: 400 });
  }
  if (!isAllowedMime(contentType)) {
    return NextResponse.json({ error: 'Blocked mime type' }, { status: 415 });
  }
  // TODO: Use AWS SDK to create a real presigned POST/PUT URL.
  // This is a stub so you can wire the client side now.
  const dummy = {
    uploadUrl: 'https://example-bucket.s3.amazonaws.com/dummy',
    method: 'PUT',
    headers: { 'Content-Type': contentType },
    maxBytes: size,
  };
  return NextResponse.json(dummy);
}
