# Prohibited Items (Draft)
List banned and restricted categories with examples and enforcement approach.
