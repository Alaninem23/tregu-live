# Returns & Refunds (Draft)
Outline eligibility, timelines, who pays return shipping, and evidence requirements.
