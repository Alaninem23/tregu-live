# Terms of Service (Draft)
Define roles (platform vs. merchants), listing rules, dispute process, governing law, limitation of liability, termination, etc.
