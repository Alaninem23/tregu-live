# Privacy Policy (Draft)
Describe personal data collected, purposes, processors, retention, data subject rights, contact, and region-specific clauses.
