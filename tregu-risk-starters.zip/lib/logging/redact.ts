// Redact common PII before logging
export function redactPII(input: unknown): unknown {
  const str = typeof input === 'string' ? input : JSON.stringify(input);
  const email = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
  const phone = /\b(\+?\d[\d\s().-]{7,}\d)\b/g;
  const card = /\b(?:\d[ -]*?){13,19}\b/g;
  return str
    .replace(email, '[REDACTED_EMAIL]')
    .replace(phone, '[REDACTED_PHONE]')
    .replace(card, '[REDACTED_CARD]');
}
