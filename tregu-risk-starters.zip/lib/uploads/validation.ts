export function isAllowedMime(mime: string, allowListCsv = process.env.UPLOAD_ALLOWED_MIME || '') {
  const list = allowListCsv.split(',').map(s => s.trim()).filter(Boolean);
  return list.length === 0 ? false : list.includes(mime);
}
export function isUnderMax(sizeBytes: number, maxMb = Number(process.env.UPLOAD_MAX_MB || '10')) {
  return sizeBytes <= maxMb * 1024 * 1024;
}
