export const flags = {
  enableSignups: process.env.FEATURE_ENABLE_SIGNUPS === 'true',
  enableListings: process.env.FEATURE_ENABLE_LISTINGS === 'true',
  enablePayouts: process.env.FEATURE_ENABLE_PAYOUTS === 'true',
  maintenanceMode: process.env.MAINTENANCE_MODE === 'true',
} as const;
