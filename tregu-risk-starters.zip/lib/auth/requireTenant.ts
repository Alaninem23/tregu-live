export function requireTenant(
  user: { tenantId?: string; role?: string } | null | undefined,
  resourceTenantId: string
) {
  if (!user?.tenantId) {
    const err = new Error('Unauthorized');
    // @ts-ignore
    err.status = 401;
    throw err;
  }
  if (user.tenantId !== resourceTenantId && user.role !== 'admin') {
    const err = new Error('Forbidden');
    // @ts-ignore
    err.status = 403;
    throw err;
  }
}
