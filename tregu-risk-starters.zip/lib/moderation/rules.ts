export const prohibited = [
  // Regulated/illegal items examples
  /firearm|gun|ammunition|silencer/i,
  /explosive|grenade|dynamite|fireworks/i,
  /counterfeit|fake\s+branded/i,
];

export const riskyPhrases = [
  /wire\s*transfer/i,
  /pay\s*off-platform/i,
  /contact\s*me\s*at\s*\+?\d/i,
  /email\s*me\s*at\s*[\w.+-]+@[\w.-]+/i,
];

export function scanText(text: string) {
  for (const r of prohibited) {
    if (r.test(text)) return { decision: 'block', reason: r.toString() };
  }
  for (const r of riskyPhrases) {
    if (r.test(text)) return { decision: 'review', reason: r.toString() };
  }
  return { decision: 'allow' as const };
}
